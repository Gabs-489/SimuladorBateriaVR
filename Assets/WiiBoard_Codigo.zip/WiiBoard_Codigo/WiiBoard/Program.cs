﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using WiimoteLib;

namespace WiiFitBoardBackend
{
    class Program
    {
        private static Wiimote wiiDevice;
        private static UDPSocket client = new UDPSocket();

        static void Main(string[] args)
        {
            Console.WriteLine("=== WiiFit Board Backend ===");

            // Configurar cliente UDP
            client.Client("127.0.0.1", 27335);
            Console.WriteLine("UDP Client configurado en puerto 27335");

            // Intentar conectar Wii Balance Board
            bool connected = Attempt_Connect();
            Console.WriteLine(connected ? "Wii Balance Board conectada!" : "Error: No se pudo conectar");

            if (connected)
            {
                Console.WriteLine("Enviando datos... Presiona cualquier tecla para salir.");
                Console.ReadKey();
                wiiDevice.Disconnect();
            }

            Console.WriteLine("Programa terminado.");
        }

        // Intentar conectar con el dispositivo
        private static bool Attempt_Connect()
        {
            try
            {
                // Buscar todos los dispositivos Wii conectados
                var deviceCollection = new WiimoteCollection();
                deviceCollection.FindAllWiimotes();

                if (deviceCollection.Count == 0)
                {
                    Console.WriteLine("No se encontraron dispositivos Wii.");
                    return false;
                }

                for (var i = 0; i < deviceCollection.Count; i++)
                {
                    wiiDevice = deviceCollection[i];

                    // Si hay múltiples dispositivos, preguntar cual usar
                    if (deviceCollection.Count > 1)
                    {
                        var devicePathId = new Regex("e_pid&.*?&(.*?)&")
                            .Match(wiiDevice.HIDDevicePath)
                            .Groups[1]
                            .Value.ToUpper();

                        if (!Choose_Device(devicePathId, i + 1, deviceCollection.Count))
                            continue;
                    }

                    // Conectar y configurar
                    wiiDevice.Connect();
                    wiiDevice.SetReportType(InputReport.IRAccel, true);
                    wiiDevice.SetLEDs(true, false, false, false);

                    // Configurar evento para cuando cambien los datos
                    wiiDevice.WiimoteChanged += WiiDevice_WiimoteChanged;

                    Console.WriteLine($"Conectado al dispositivo {i + 1}");
                    break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return false;
            }
            return true;
        }

        // Evento que se ejecuta cuando cambian los datos del Wii Balance Board
        private static void WiiDevice_WiimoteChanged(object sender, WiimoteChangedEventArgs e)
        {
            var wm = (Wiimote)sender;

            // Verificar que es una Balance Board
            if (wm.WiimoteState.ExtensionType == ExtensionType.BalanceBoard)
            {
                var bb = wm.WiimoteState.BalanceBoardState;

                // Obtener valores en kilogramos de cada sensor
                var topLeft = bb.SensorValuesKg.TopLeft;
                var topRight = bb.SensorValuesKg.TopRight;
                var bottomLeft = bb.SensorValuesKg.BottomLeft;
                var bottomRight = bb.SensorValuesKg.BottomRight;

                // Enviar cada sensor por UDP a Unity
                Send_Data("rTL", (float)topLeft);
                Send_Data("rTR", (float)topRight);
                Send_Data("rBL", (float)bottomLeft);
                Send_Data("rBR", (float)bottomRight);

                // Mostrar en consola (opcional)
                Console.WriteLine($"TL:{topLeft:F2} TR:{topRight:F2} BL:{bottomLeft:F2} BR:{bottomRight:F2}");

                // Enviar timestamp para medir latencia
                Send_Data("timestamp", (float)DateTime.Now.TimeOfDay.TotalMilliseconds);
            }
        }

        // Función para seleccionar dispositivo
        private static bool Choose_Device(string devicePathId, int index, int len)
        {
            return Ask_Yes_No_Question($"¿Conectar al dispositivo HID {devicePathId} ({index} de {len})?");
        }

        // Función para preguntas sí/no
        private static bool Ask_Yes_No_Question(string str)
        {
            Console.WriteLine(str + " [Y]/[n]");
            return Console.ReadKey(true).Key != ConsoleKey.N;
        }

        // Enviar datos por UDP
        private static void Send_Data(string name, float value)
        {
            client.Send($"{name}:{value}");
        }
    }

    // Clase UDP Socket para comunicación
    public class UDPSocket
    {
        protected Socket _socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        protected const int bufSize = 8 * 1024;
        protected State state = new State();
        protected EndPoint epFrom = new IPEndPoint(IPAddress.Any, 0);
        protected AsyncCallback recv = null;

        public class State
        {
            public byte[] buffer = new byte[bufSize];
        }

        public void Server(string address, int port)
        {
            _socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.ReuseAddress, true);
            _socket.Bind(new IPEndPoint(IPAddress.Parse(address), port));
            Receive();
        }

        public void Client(string address, int port)
        {
            _socket.Connect(IPAddress.Parse(address), port);
        }

        public void Send(string text)
        {
            byte[] data = Encoding.ASCII.GetBytes(text);
            _socket.BeginSend(data, 0, data.Length, SocketFlags.None, (ar) =>
            {
                State so = (State)ar.AsyncState;
                int bytes = _socket.EndSend(ar);
            }, state);
        }

        public virtual void Receive()
        {
            _socket.BeginReceiveFrom(state.buffer, 0, bufSize, SocketFlags.None, ref epFrom, recv = (ar) =>
            {
                State so = (State)ar.AsyncState;
                SocketError errorCode;
                int bytes = _socket.EndReceive(ar, out errorCode);
                if (errorCode != SocketError.Success)
                {
                    bytes = 0;
                }
                _socket.BeginReceiveFrom(so.buffer, 0, bufSize, SocketFlags.None, ref epFrom, recv, so);
            }, state);
        }
    }
}